// writing on a text file
#include <iostream>
#include <fstream>
#include<string>
#include<sstream>
using namespace std;

int main () {
 
 string name[3];
string score[3];
/*ofstream myfile ("example.txt");
  if (myfile.is_open())
  {	
  for(int i=0;i<3;i++)
  	{	  cin>>name[i]>>score[i];
    myfile << name[i] <<"\n";
    myfile << score[i] <<"\n";
	
	}
  
  }
    myfile.close();
  //else cout << "Unable to open file"; 

 */
  
 
  string line;
  int i=0;
  ifstream myfile1 ("example.txt");
 	if(!myfile1)	{ cout<<"file error";
 						return 0;}
 						


  if (myfile1.is_open())
  {
    while ( !myfile1.eof() )
{

	getline (myfile1,name[i]);
    getline (myfile1,score[i]);
    
	i++;
	if(i<3)
		continue;
	else
		break;	
		
		}
 
 
 cout<<endl<<endl;
 for(int i=0; i<3;i++) 
  cout << name[i] << '\t'<<score[i]<< endl;
  
  myfile1.close();
  
 
 ifstream f("Example.txt"); //taking file as inputstream
   string str;
   if(f) {
      ostringstream ss;
      ss << f.rdbuf(); // reading data
      str = ss.str();
   }
   cout<<str;
 
  
  
  
  
  }
   

// else cout << "Unable to open file"; 
//myfile1.close();
  return 0;

  
 
}


