/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * Shape of each piece is represented by rows in the array.
 * TIP: Name the array what is already been coded to avoid any unwanted errors.
 */
 
 /*Name: Syed Huzaifa Tahir Zaidi
   Final Project
   Section J
   Roll No. 22i-1150*/
 
 
 int BLOCKS[7][4] = {{1,3,5,7},{1,3,5,0},{1,3,5,4},{0,2,1,3},{1,3,2,4},{0,2,3,5},{2,1,3,5}};
 
 
