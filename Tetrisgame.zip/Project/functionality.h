/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * You need to define the required function in the part instructed here below.
 * Avoid making any unnecessary changes, particularly the ones you don't understand.
 * The different pieces should be defined using an array - uncomment the following code once you are done creating the array.
 * TIP: Understand thoroughly before getting started with coding.
 * */

//---Piece Starts to Fall When Game Starts---//

/*Name: Syed Huzaifa Tahir Zaidi
   Final Project
   Section J
   Roll No. 22i-1150*/



void fallingPiece(float& timer, float& delay, int& colorNum,int &level_no){
 
    
    
    int n;
    
    if (timer>delay){
    
        for (int i=0;i<4;i++){
            point_2[i][0]=point_1[i][0];
            point_2[i][1]=point_1[i][1];
            point_1[i][1]+=1;                   //How much units downward
        }
        
        
        
        if (!anamoly()){
            
            for(int i = 0; i<4;i++){
            	gameGrid[point_2[i][1]][point_2[i][0]] = colorNum;
            	
            }
            
               n=nextn;
               colorNum=nextColor;
               
                for (int i=0;i<4;i++){
                    point_1[i][1] = BLOCKS[n][i] % 2;
                    point_1[i][0] = BLOCKS[n][i] / 2;
                }
        if(level_no==1)
        {       
            nextColor=1+rand()%7;
            nextn=rand()%4;
            }
        else if(level_no==2)
        {
            nextColor=1+rand()%7;
            nextn=rand()%7;
            }
              
        }
        timer=0;
        
    }
 
 
}
/////////////////////////////////////////////
///*** START CODING YOUR FUNTIONS HERE ***///

void Bomb(int bomb[],int bomb2[],float& ntimer, float& ndelay, int& color,int &level_no)
{
 int n;
   bool check;
  
    
 // 1D array so making a check just like anamoly to make the bomb fall within the boundaries. 
  if(bomb[0]<0 ||  bomb[0]>=N || bomb[1]>=M)
   check=false;  
  else if(gameGrid[bomb[1]][bomb[0]])
  check=false;
  else
  check=true;
 
// Basically the same as falling piece except it is used to drop a bomb.
 if (ntimer>1.5){  
  bomb2[0]=bomb[0];
  bomb2[1]=bomb[1];
  bomb[1]+=1;
  
 if(!check)
  {
   
    gameGrid[bomb2[1]][bomb2[0]]=color;
    
    color=1+rand()%7;
    
    bomb[0]=rand()%10;
    bomb[1]=0;
    }

  
        ntimer=0;
    
  }
  
}


void bombdropped(int bomb[],int bomb2[],int &color)
{
// If Bomb colour matches the color of block then the whole grid will be destroyed.

 if (gameGrid[bomb[1]][bomb[0]]==color)
 {
  for(int i=0;i<20;i++)
   {
    for(int j=0;j<10;j++)
    {
     gameGrid[i][j]=0;
     }
    }
   }  
   

 }





void nextpiece()
{

// Holds the value of next n in its parameter until anamoly is true an show next incoming piece
  if(anamoly())
  {
    for (int i=0;i<4;i++){
                    point_5[i][1] = BLOCKS[nextn][i] % 2;
                    point_5[i][0] = BLOCKS[nextn][i] / 2;
                }
        }

}






void Shadow(int& colorNum)
{
//copy the values of point_1 into point_3 so same  shapes are made 
  for(int i=0;i<4;i++){
     
     point_3[i][0] = point_1[i][0];
     point_3[i][1] = point_1[i][1];
   }


 
// increasing the y-coordinates of point 3 until it reaches M or any other point where block is already present        
 while(anamoly()){
  for(int i=0;i<4;i++){
     if(point_1[i][1]<M){
     point_4[i][0] = point_3[i][0];
     point_4[i][1] = point_3[i][1];
     point_3[i][1]+=1;
             }
     
           }
     }
        
//replacing the value of point3 from point4 which holds previous value of point 3 so that the block does not go inside the frame. 
 if (!anamoly()){
      for (int i=0;i<4;i++)
      {
       point_3[i][0]=point_4[i][0];
            point_3[i][1]=point_4[i][1];
            }
 
   }       
}

void harddrop(bool& spacebar){
     
    if(spacebar){
// if spacebar is pressed than the block will fall upon until one of the conditions of the anamoly becomes true.    
    while(anamoly()){ 
    	
    	
     for(int i=0;i<4;i++){
     if(point_1[i][1]<M){
     point_2[i][0] = point_1[i][0];
     point_2[i][1] = point_1[i][1];
     point_1[i][1]+=1;
             }
  //Once the block reaches the anamoly condition the loop will exit.   
           }
        }
     }
     
// replacing point1 with point2 which hold the previous coordinates of point1 so that the block does no go inside the boundary or inside other blocks.     
     if (!anamoly()){
      for (int i=0;i<4;i++)
      {
       point_1[i][0]=point_2[i][0];
            point_1[i][1]=point_2[i][1];
            }
     }
      
}



void shift(int delta_x)
{
// copying the values of point1 into point2 
for (int i=0;i<4;i++)
      {
       point_2[i][0]=point_1[i][0];
            point_2[i][1]=point_1[i][1];
            }
// if delta_x is positive the block will move to the right side because delta_x will be added else if delta_x is negative block will move to left because delta_x will be subtracted from point1.            
    
    
    
    for(int i=0;i<4;i++)
        { 
           
             point_1[i][0]+=delta_x;
                }
 // replacing point1 with point2 which hold the previous coordinates of point1 so that the block does no go inside the boundary or inside other blocks.                
     if (!anamoly()){
      for (int i=0;i<4;i++)
      {
       point_1[i][0]=point_2[i][0];
            point_1[i][1]=point_2[i][1];
            }
     }
}

void rotation(bool rotate)
{
 if(rotate)
{
// copying the values of point1 into point2
for (int i=0;i<4;i++){
            point_2[i][0]=point_1[i][0];
            point_2[i][1]=point_1[i][1];
            }
//Taking a center point of a block by storing its xy- coordinates.
  int centerx=point_1[1][0];
  int centery=point_1[1][1];
//Rotating the rest of the blocks around the center points.  
  for (int i=0;i<4;i++)
  {
  
   int x=point_1[i][1]-centery;
   int y=point_1[i][0]-centerx;
   point_1[i][0]=centerx-x;
   point_1[i][1]=centery+y;
   }
// replacing point1 with point2 which hold the previous coordinates of point1 so that the block does no go inside the boundary or inside other blocks.  

if (!anamoly()){
 for(int i=0;i<4;i++)
 {

  point_1[i][1]=point_2[i][1];
  point_1[i][0]=point_2[i][0];
 
  
  
    }
  }
 }
}

void checkline(int &level_no)
{
// Row holds the value of M-1=19.
  int line=0;
  int row=M-1;
//Checking each column of each row and copying to check if the whole row is full of boxes or not. If a single block (gameGrid[i][j]) returns 0 that means count wont be incremented. This means that count value will be less than 9 so the upper row will not be copied upon the current row.
  for(int i=M-1;i>0;i--)
  {
   int count=0;
   for(int j=0;j<N;j++)
   {
    if(gameGrid[i][j])
    {
     count++;
     }
     gameGrid[row][j]=gameGrid[i][j];
     
    }
 // This holds the number of cleared lines simultaneously so that it can be further used for scoring.   
    if(count==N)
    	line++;
 // This basically copies the upper row onto the lower one if the row is completely filled.   
    if(count<N)
    {    
     row--;
     }
   }
   
// Algorithm to perform scoring calculations 
   if(line==1)
   {score+=10*level_no;}
   if(line==2)
   { score+=30*level_no;}
   if(line==3)
   {score+=60*level_no;}
   if(line==4)
   { score+=100*level_no;}
   
 
}


 int isGameOver()
 {
// if a single columns is fully filled from 0 to 9 that means that the game has reached its end and count will be returned 1. If count is mean that means game is over and it will be returned to the main functions where output is provided.

 	int count=0;
 	for(int i=0; i<N ; i++)
 		if(gameGrid[0][i])
 			count=1;
 	   
 	   if (count==1)
 	     return 1;
 	   else 
 	    return 0;
 			
 			
 
 }

 

///*** YOUR FUNCTIONS END HERE ***///
/////////////////////////////////////
