/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * You don't need to change anything in the driver code/main function except the part(s) where instructed.
 * You are expected to define your functionalities in the "functionality.h" header and call them here in the instructed part(s).
 * The game is started with a small box, you need to create other possible in "pieces.h" file in form of array.
    E.g., Syntax for 2 pieces, each having four coordinates -> int Pieces[2][4];
 * Load the images into the textures objects from img directory.
 * Don't make any changes to the "utils.h" header file except for changing the coordinate of screen or global variables of the game.
 * SUGGESTION: If you want to make changes in "utils.h", do it once you complete rest of the functionalities.
 * TIP: You can study SFML for drawing scenes, sprites and window.
 * */
 
 /*Name: Syed Huzaifa Tahir Zaidi
   Final Project
   Section J
   Roll No. 22i-1150*/
 
 
 
 
 
# include<iostream>
# include<string>
#include <SFML/Graphics.hpp>
# include<SFML/Audio.hpp>
#include <sstream>
#include <time.h>
#include<fstream>
#include "utils.h"
#include "pieces.h"
#include "functionality.h"
using namespace sf;
using namespace std;

void showscoreboard(string str2,int score); 
int main(){
    srand(time(0));
    RenderWindow window(VideoMode(320, 480), title);
    
    
    Texture obj1, obj2, obj3, obj4,obj5,obj6,obj7,obj8,obj9,obj10,obj11,obj12;
    
   sf::Music music;
   if(!music.openFromFile("img/gamesound.ogg"))
   {}
   music.play(); 
   
   sf::Font font;
    
   font.loadFromFile("img/Roboto-Black.ttf");
    
    sf::Text text;
    text.setFont(font);
    obj1.loadFromFile("img/tiles.png");
    obj2.loadFromFile("img/background.png");
    obj3.loadFromFile("img/frame.png");
    obj4.loadFromFile("img/gameover.png");
    obj5.loadFromFile("img/menu.png");
    obj6.loadFromFile("img/rules.png");  
    obj7.loadFromFile("img/level.png");
    obj8.loadFromFile("img/submenu.png");
    obj9.loadFromFile("img/shadow.png");
    obj10.loadFromFile("img/rules2.png");
    obj11.loadFromFile("img/background2.png");
    obj12.loadFromFile("img/background3.png");
    
    Sprite sprite(obj1), background(obj2), frame(obj3) ,gameover(obj4), menu(obj5), rules(obj6),level(obj7),submenu(obj8),shadow(obj9),rules2(obj10),background2(obj11),background3(obj12);
    int delta_x=0, colorNum=nextColor,level_no=0,color=1,bomb[2]={rand()%10,0},bomb2[2],z=rand()%4;
   string str2;
    float timer=0, delay=0.3,ntimer=0,ndelay=0.3;
    bool rotate=0,flag=1,spacebar=0,x=0,gametstart= false;
    string scorestr[10];int hscore[10];
    Clock clock;
    while (window.isOpen()){
        float time = clock.getElapsedTime().asSeconds();
      
        clock.restart();
        timer+=time;
        ntimer+=time;
        
        //---Event Listening Part---//
        Event e, event;
        while (window.pollEvent(e)){                    //Event is occurring - until the game is in running state
            if (e.type == Event::Closed)                   //If cross/close is clicked/pressed
                window.close();                            //Opened window disposes
           
		    if (e.type == Event::KeyPressed) {             //If any other key (not cross) is pressed
            	     if(!gametstart){	
            		switch(e.key.code)
            		{
				           	
	  
				   case Keyboard::Num1:
				   
				  
				 while(!gametstart)
				 {  
				  window.draw(level);
				   window.display();
				   
				
				
				  				   
				if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num6))
				   {
				   level_no=1;
				 
				gametstart=true;
				
				
				   }
				 else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Num7))
				   {
			   		level_no=2;
			   		gametstart=true;
				
				
				   }}
			   		break;
			   	//num1	
			   	   case Keyboard::Num2:
			   	  
			   	   
			   	   
			   	   window.draw(background2);
			   	   
			   	     showscoreboard(str2,score);
                                   text.setString("Name  Score \n Waqar  10000 \n Nasir  9000 \n Raza  8000 \n Taha  7000 \n Arfa  6000 \n Muhammad  5000 \n Hammad  4000 \n Amna  3000\n");
                                   text.setCharacterSize(24);
                                   text.setFillColor(sf::Color::White);
                                   text.setStyle(sf::Text::Bold | sf::Text::Underlined);
                                   text.setPosition(sf::Vector2f(28,50));
                                   window.draw(text);
                                   
                                   window.display();
				   break;
				   
				   case Keyboard::Num3:
				   
				   window.draw(rules);
                                   window.display();
                                   
				   break;
				   
				   case Keyboard::Num4:
					   		exit(0);
					break;}}
		if(gametstart==true)
		{		
			switch(e.key.code)
            		{		
				case Keyboard::H :
                   gametstart=false;
                 window.draw(submenu);
                 	window.display(); 
                 while(!gametstart){
                   		
               
                
                  // while(true){
                    		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num5))
        				{
        				gametstart=true;
            					break;
        				} 
        		        else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Num1))
        		           {
        		            
        		            
        		              delta_x=0, colorNum=nextColor,level_no=0;
                                       timer=0, delay=0.3,ntimer=0;
                                       rotate=0,spacebar=0,x=0,gametstart= false;
                                      score=0,bomb[0]=rand()%10,bomb[1]=0,bomb2[2];
                                     
                                     for(int i=0;i<20;i++)
                                      { 
                                       for(int j=0;j<10;j++)
                                       {
                                         gameGrid[i][j]=0;
                                         }
                                        }      
                                      for(int i=0;i<4;i++)
                                     {
                                      for(int j=0;j<2;j++)
                                      {
                                       point_1[i][j]=0;
                                       }}      
                                           
                                    while(!gametstart)
				 {  
				  window.draw(level);
				   window.display();
				   
				
				
				  				   
				if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num6))
				   {
				   level_no=1;
				   
				gametstart=true;
				
				
				   }
				 else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Num7))
				   {
			   		level_no=2;
			   		gametstart=true;
				
				
				   }}
                                     
        		              }	
        		        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num2))
        		        {
        		            
			   	   window.draw(background3);
        		           showscoreboard(str2,score);
                                   text.setString("Name  Score \n Waqar  10000 \n Nasir  9000 \n Raza  8000 \n Taha  7000 \n Arfa  6000 \n Muhammad  5000 \n Hammad  4000 \n Amna  3000\n");
                                   text.setCharacterSize(24);
                                   text.setFillColor(sf::Color::White);
                                   text.setStyle(sf::Text::Bold | sf::Text::Underlined);
                                   text.setPosition(sf::Vector2f(28,50));
                                   window.draw(text);
                                   window.display();
        		        }
				else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num3))
        				{	
						window.draw(rules2);
                                                window.display();
                                                }
				else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Num4))	
				        {
				           exit(0);
				           }
					}	
						break;	
					
					
				
					  
			             case Keyboard::Space:
			                   spacebar=1;
			                   
			                  break; 		
			   		
			  		case Keyboard::Up:          //Check if the other key pressed is UP key
                    			rotate = true; 
					break;          
			  
			  		case Keyboard::Left:     //Check if the other key pressed is LEFT key
					delta_x = -1;
                    			break;
			  
			  
			  		case Keyboard::Right:    //Check if the other key pressed is RIGHT key
                  			  delta_x = 1;            //Change in X-Axis - Positive 
                  			  break;
                    
                		       		
			  
			  	  		  
			  
			   } //switch
            				     
			} 
		} //if e.type
			 
	                           
            
        } //while
      
         if (Keyboard::isKeyPressed(Keyboard::Down))   //Just another way to detect key presses without event listener
            delay=0.05;
        else if(level_no==1)
        {
            delay=0.5;
            }  
        else if(level_no==2)
        {
            delay=0.3;
            }
                                              //If DOWN key is pressed, delay in falling piece decreases from 0 to 0.05


        ///////////////////////////////////////////////
        ///*** START CALLING YOUR FUNCTIONS HERE ***///
       
      
       
       if(flag)
      {
        	window.draw(menu);
        	
      		window.display();
     		flag=false;
     		
     		
       }
   ///// Function Calling here.  
      if(gametstart)
      {
         
          shift(delta_x);
          rotation(rotate);     
	  harddrop(spacebar);
          Bomb(bomb,bomb2,ntimer, ndelay, color,level_no);
         bombdropped(bomb,bomb2,color);break;}
          fallingPiece(timer, delay, colorNum,level_no);
        
         
                    
         Shadow(colorNum);
	  nextpiece();
	  checkline(level_no);
          delta_x=0,rotate=false,spacebar=0; // reseting all the variables before calling function again
   ////// Function calling here .      
          
       
     // code to display score and next piece 
         string str1 = to_string(score);
         window.clear(Color::Black);
        
        window.draw(background);
        
    
         text.setString("Score:");
         text.setCharacterSize(20);
         text.setFillColor(sf::Color::White);
         text.setStyle(sf::Text::Bold | sf::Text::Underlined);
         text.setPosition(sf::Vector2f(225,125));
         window.draw(text);
         
         text.setString("Next piece:");
         text.setCharacterSize(15);
         text.setFillColor(sf::Color::White);
         text.setStyle(sf::Text::Bold | sf::Text::Underlined);
         text.setPosition(sf::Vector2f(225,280));
         window.draw(text);
         
         text.setString(str1);
         text.setCharacterSize(20);
         text.setFillColor(sf::Color::Cyan);
         text.setPosition(sf::Vector2f(250,160));
         window.draw(text);
     // code to display score and next piece 
          
     
	  ///*** YOUR CALLING STATEMENTS END HERE ***///
        //////////////////////////////////////////////   
    
   
   // Code for drawing bombs    
	   
            sprite.setTextureRect(IntRect(color*18,0,18,18));
            sprite.setPosition(bomb[0]*18,bomb[1]*18);
            sprite.move(28,31);
            window.draw(sprite);
          
   // Code for drawing bombs.    
        
        
        for (int i=0; i<M; i++){
            for (int j=0; j<N; j++){
                if (gameGrid[i][j]==0)
                    continue;
                sprite.setTextureRect(IntRect(gameGrid[i][j]*18,0,18,18));
                sprite.setPosition(j*18,i*18);
                sprite.move(28,31); //offset
                window.draw(sprite);
            }
        }
  
	    for (int i=0; i<4; i++){
            sprite.setTextureRect(IntRect(colorNum*18,0,18,18));
            sprite.setPosition(point_1[i][0]*18,point_1[i][1]*18);
            sprite.move(28,31);
            window.draw(sprite);
          }
    //Code for drawing shadows.      
       for (int i=0; i<M; i++){
            for (int j=0; j<N; j++){
                if (gameGrid[i][j]==0)
                    continue;
                shadow.setTextureRect(IntRect(gameGrid[i][j]*18,0,18,18));
                shadow.setPosition(j*18,i*18);
                shadow.move(28,31); //offset
                window.draw(shadow);
                
            }
        }
       
	    for (int i=0; i<4; i++){
            shadow.setTextureRect(IntRect(colorNum*18,0,18,18));
            shadow.setPosition(point_3[i][0]*18,point_3[i][1]*18);
            shadow.move(28,31);
            window.draw(shadow);
            }
      // Code for drawing shadows. 
       
	 
  	// Code for drawing block for next suggestion.		 
	    for (int i=0; i<4; i++){
            sprite.setTextureRect(IntRect(colorNum*18,0,18,18));
          sprite.setPosition(point_5[i][0]*18,point_5[i][1]*18);
            sprite.move(230,300);
            window.draw(sprite);
          }
       // Code for drawing block for next suggestion.
          
         
        //---The Final on Which Everything is Drawn Over is Loaded---//
        window.draw(frame);
    
    // Code for Displaying game over and displaying options to restart again.    
        if(isGameOver())
         {	
            
          	gametstart=false;
          	window.draw(gameover);
          	window.display();
          	while(!gametstart){
          	
          	if(sf::Keyboard::isKeyPressed(sf::Keyboard::Num1))
        		           {
        		            
        		            
        		              delta_x=0, colorNum=nextColor,level_no=0;
                                       timer=0, delay=0.3,ntimer=0;
                                       rotate=0,spacebar=0,x=0,gametstart= false;
                                      score=0,bomb[0]=rand()%10,bomb[1]=0,bomb2[2];
                                     
                                     for(int i=0;i<20;i++)
                                      { 
                                       for(int j=0;j<10;j++)
                                       {
                                         gameGrid[i][j]=0;
                                         }
                                        }      
                                      for(int i=0;i<4;i++)
                                     {
                                      for(int j=0;j<2;j++)
                                      {
                                       point_1[i][j]=0;
                                       }}
             		     while(!gametstart)
				 {  
				  window.draw(level);
				   window.display();
				   
				
				
				  				   
				if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num6))
				   {
				   level_no=1;
				   
				gametstart=true;
				
				
				   }
				 else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Num7))
				   {
			   		level_no=2;
			   		gametstart=true;
				
				
				   }}}
			  	 else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num2))
        		        {
        		            
			   	   window.draw(background2);
        		           showscoreboard(str2,score);
                                   text.setString("Name  Score \n Waqar  10000 \n Nasir  9000 \n Raza  8000 \n Taha  7000 \n Arfa  6000 \n Muhammad  5000 \n Hammad  4000 \n Amna  3000\n");
                                   text.setCharacterSize(24);
                                   text.setFillColor(sf::Color::White);
                                   text.setStyle(sf::Text::Bold | sf::Text::Underlined);
                                   text.setPosition(sf::Vector2f(28,50));
                                   window.draw(text);
                                   window.display();
        		        }
                              else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Num3))
        				{	
        				  
						window.draw(rules);
                                                window.display();
                                                }
				else if(sf::Keyboard::isKeyPressed(sf::Keyboard::Num4))	
				        {
				           exit(0);
				           }
					              
              }
           showscoreboard(str2,score);
         }
   // Code for Displaying game over and displaying options to restart again.      
        
        //---The Window that now Contains the Frame is Displayed---//S
        window.display();
      } //gamestart
    
    }
    
	


    return 0;
}





void showscoreboard(string str2,int score)
{
string name[3];
 string score1[3];

  int i=0;
  //////////////////// code to read from file////////////
 /* ifstream myfile1 ("example.txt");
  
    while ( !myfile1.eof() )
{
	getline (myfile1,str2);
    	getline (myfile1,score1[i]);
    
	i++;
	if(i<3)
		continue;
	else
		break;	
		
		}
  
  myfile1.close();
*/
///////////////code to write to file////////////

ofstream myfile ("example.txt",ios::app);
  	
  		  
    myfile << "Palyer"<<"\t";
    myfile << score <<"\n";
	
	
  
     myfile.close();
   
/////////////// code to read from file and store in a string//////////
 
 ifstream f("Example.txt"); //taking file as inputstream
   
   if(f) {
      ostringstream ss;
      ss << f.rdbuf(); // reading data
      str2 = ss.str();
   }
  cout<<str2;
 f.close();    
}





